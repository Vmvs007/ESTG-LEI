/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp08_objectmanagement;

/**
 *
 * @author Utilizador
 */
public class ContainerOfObjects {

    private final int DEFAULT_SIZE = 100;
    private Object objects[];

    public ContainerOfObjects(Object[] objects) {
        this.objects = objects;
    }

    public ContainerOfObjects() {
        objects = new Object[DEFAULT_SIZE];
    }

    public ContainerOfObjects(int maxSize) {
        objects = new Object[maxSize];
    }

    protected boolean addObject(Object newObject) {
        int x = 0;
        while (x < objects.length) {
            if (objects[x] == null) {
                objects[x] = newObject;
                return true;
            }
            x++;
        }
        return false;
    }

   protected Object removeObject(int position) {
        Object x = objects[position];
        objects[position] = null;
        return x;
    }

    protected boolean setObject(int position, Object newObject) {
        objects[position]= newObject;
        return true;
    }

    protected int findObject(Object obj) {
                int x = 0;
        while (x < objects.length) {
            if (objects[x] == obj) {
                return x;
            }
            x++;
        }
        return -1;
    }

}
