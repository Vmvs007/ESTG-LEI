/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp04_ex01_classuser;

/**
 *
 * @author Utilizador
 */
public class UserTestDrive {
    public static void main(String[] args){
        System.out.println("Id: " + User.id);
        System.out.println("Name: " + User.name);
        System.out.println("Email: " + User.email);
    }
}
