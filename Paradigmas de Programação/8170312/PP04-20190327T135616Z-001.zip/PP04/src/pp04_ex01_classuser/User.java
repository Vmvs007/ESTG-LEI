/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp04_ex01_classuser;

/**
 *
 * @author Utilizador
 */
public class User {

       static int id = 8170312;
       static String name = ("Vitor");
       static String email = ("vmvs007@gmail.com");
       public static Expenses expense = new Expenses();
}
