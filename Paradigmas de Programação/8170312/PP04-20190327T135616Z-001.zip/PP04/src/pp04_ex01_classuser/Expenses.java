/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp04_ex01_classuser;

/**
 *
 * @author Utilizador
 */
public class Expenses {

    private static final int NUMBER_OF_DAYS = 31; //Para o mês de Março

   private static int car; //Despesas com carro

    //Despesas para cada dia dos mês, associando cada posição do vetor a um dia
    private static double[] carValues = new double[NUMBER_OF_DAYS]; //em Euros
    private static char[] carDescription = new char[]{'C', 'a', 'r', 'r', 'o'};

    private static int food; //Despesas com alimentação

    //Despesas para cada dia dos mês, associando cada posição do vetor a um dia
    private static int number2;
    private static double[] foodValues = new double[NUMBER_OF_DAYS]; //em Euros
    private static char[] foodDescription = new char[]{'A', 'l', 'i', 'm', 'e', 'n', 't', 'a', 'ç', 'ã', 'o'};

    public int getNumber(){
        return number2;
    }
    public void sestNumber(int value){
        number2 = value;
    }
    
    void printExpenses() {
        int i, j=1, somaCar=0, somaFood=0;

        for (i = 0; i < 31; i++) {
            carValues[i]=i;
            somaCar= somaCar+i;
            foodValues[i]=i;
            somaFood= somaFood+i;
            System.out.println("Dia "+ j);
            System.out.println("Gastos Automóveis: " + carValues[i]);
            System.out.println("Gastos Alimentares: " + foodValues[i] + "\n");
            j++;
        }
        
        System.out.println("Gastos Automóveis Totais: " + somaCar);
        System.out.println("Gastos Alimentares Totais: " + somaFood+ "\n");
        System.out.println("Gastos Automóveis Médios Diários: " + (somaCar/NUMBER_OF_DAYS));
        System.out.println("Gastos Alimentares Médios Diários: " + (somaFood/NUMBER_OF_DAYS));
    }
}
