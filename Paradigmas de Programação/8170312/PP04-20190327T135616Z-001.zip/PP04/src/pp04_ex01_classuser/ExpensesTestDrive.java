/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp04_ex01_classuser;

/**
 *
 * @author Utilizador
 */
public class ExpensesTestDrive {
    static User user1;
    public static void main(String[] args){
        
      user1 = new User();
      user1.expense.printExpenses();
     
    } 
}
